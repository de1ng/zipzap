<?php
	session_start();
	if(!isset($_SESSION['admin_uid'])){ header('location:login.php'); exit;}
	include_once('classes/dbo.class.php');
	
	$q = "SELECT * FROM lead";
	$res = $db->get($q);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon1.png">
    <title></title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="../plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="../plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="../plugins/bower_components/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="../plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <!-- Calendar CSS -->
    <link href="../plugins/bower_components/calendar/dist/fullcalendar.css" rel="stylesheet" />
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/default.css" id="theme" rel="stylesheet">
	<style>
		.test{
    text-overflow: hidden !important; 
		}
	</style>
</head>

<body class="fix-header">
    <!-- ============================================================== -->
    <!-- Preloader -->
    <!-- ============================================================== -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" />
        </svg>
    </div>
    <!-- ============================================================== -->
    <!-- Wrapper -->
    <!-- ============================================================== -->
    <div id="wrapper">
		<?php include_once('includes/inc.header.nav.php'); ?>
		<?php include_once('includes/inc.sidebar.php'); ?>
        
        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Leads</h4> 
					</div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li class="active">LEADS</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <!-- ============================================================== -->
                <!-- Different data widgets -->
                <!-- ============================================================== -->
                <!-- .row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title m-b-0">Add Lead</h3>
                            <form class="form-horizontal" action="process/process_add_lead.php" method="POST">
                                <div class="form-group">
                                    <label class="col-md-12">Lead Info </label>
                                    <div class="col-md-12">
										<textarea class="form-control" name="lead_info" rows="5" placeholder="Enter your description here."></textarea>
									</div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12">Mobile No.</label>
                                    <div class="col-md-12">
                                        <input type="text" name="lead_mob" class="form-control" placeholder="Ex. 9876543210" />
									</div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12">Email</label>
                                    <div class="col-md-12">
                                        <input type="text" name="lead_email" class="form-control" placeholder="Ex. user@gmail.com " />
									</div>
                                </div>
                                <input type="submit" class="btn btn-success m-r-10 " value="Submit" />
                            </form>
                        </div>
                    </div>
                </div>
                <!--/.row -->
                <!--row -->
				<div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="panel">
                            <div class="panel-heading">MANAGE LEADS</div>
                            <div class="table-responsive">
                                <table class="table table-hover manage-u-table">
                                    <thead>
                                        <tr>
                                            <th style="width:5%;" class="text-center">#</th>
                                            <th style="width:20px">Lead Information</th>
                                            <th style="width:20%;text-align:middle">Manage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
											$i = 0;
											while($row = mysqli_fetch_assoc($res)){
												$i++;
												echo '
													<tr>
														<td class="text-center">'.$i.'</td>
														<td class="test">
															<span class="font-medium ">'.$row['lead_info'].'</span><br />
															<span class="font-medium"><b>Email id : </b>'.$row['lead_email'].'</span><br />
															<span class="font-medium"><b>Mobile No. : </b>'.$row['lead_mob'].'</span>
														</td>
														<td>
															<a href="process/process_delete_jokes_category.php?cat_id='.$row['id'].'" type="button" class="btn btn-info btn-outline btn-circle btn-lg m-r-5"><i class="icon-trash"></i></a>
														</td>
													</tr>
												';
											}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
				</div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
			<?php include_once('includes/inc.footer.php'); ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="../plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="../plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!-- chartist chart -->
    <script src="../plugins/bower_components/chartist-js/dist/chartist.min.js"></script>
    <script src="../plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="../plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script src="js/dashboard1.js"></script>
    <script src="../plugins/bower_components/toast-master/js/jquery.toast.js"></script>
    <!--Style Switcher -->
    <script src="../plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>
