<?php
	session_start();
	if(!isset($_POST)){ echo "Form was empty"; exit; }
	

	$errors = Array();
	
	if(!isset($_POST['email']) && empty($_POST['email'])){
		$errors[] = "Email was empty.";
	}
	
	if(!isset($_POST['pass']) && empty($_POST['pass'])){
		$errors[] = "Password was empty.";
	}
	
	if(!empty($errors)){
		
		echo 'Errors : <hr />';
		
		echo '<ul>';
		foreach($errors as $e){
			echo '<li>'.$e.'</li>';
		}
		echo '</ul>';
		
	}
	
	include_once('../admin/classes/dbo.class.php');
	
	$q = "SELECT * FROM user WHERE user_email = '".$_POST['email']."' AND user_pass = '".md5($_POST['pass'])."';";
	$res = $db->get($q);
	if(mysqli_num_rows($res) === 1){
		$row = mysqli_fetch_assoc($res);
		$_SESSION['uid'] = $row['id'];
		$_SESSION['unm'] = $row['user_full_name'];
		echo "Success";
		exit;
	}else{
		echo "User name OR password was wrong.";
	}
	