<?php
	session_start();
	if(!isset($_POST)){ echo "Form was empty"; exit; }
	
	$errors = Array();
	
	if(!isset($_POST['id']) && empty($_POST['email'])){
		$errors[] = "You choose wrong lead.";
	}
	
	if(!empty($errors)){
		
		echo 'Errors : <hr />';
		
		echo '<ul>';
		foreach($errors as $e){
			echo '<li>'.$e.'</li>';
		}
		echo '</ul>';
		
	}
	
	include_once('../admin/classes/dbo.class.php');
	
	$get_user_lead_q = "SELECT * FROM user WHERE id = ".$_SESSION['uid'];
	$get_user_lead_res = $db->get($get_user_lead_q);
	$get_user_lead_row = mysqli_fetch_assoc($get_user_lead_res);
	if($get_user_lead_row['user_credit'] <= 0){
		echo "You don't have Credit.";
		exit;
	}
	
	$add_lead_q = "INSERT INTO lead_purchase(user_id, lead_id) VALUES('".$_SESSION['uid']."','".$_POST['id']."')";
	$db->dml($add_lead_q);
	
	$update_user_credit_q = "UPDATE user set user_credit = user_credit-1 WHERE id = '".$_SESSION['uid']."';";
	$db->dml($update_user_credit_q);
	echo "Success";
	exit;