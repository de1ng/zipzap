
(function ($) {
    "use strict";

    
    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');

    $('.validate-form').on('submit',function(){
        var check = true;

        for(var i=0; i<input.length; i++) {
            if(validate(input[i]) == false){
                showValidate(input[i]);
                check=false;
            }
        }
		
		if(check === true){
			var email = $(input[0]).val();
			var pass = $(input[1]).val();
			var dataString = 'email=' + email + '&pass=' + pass;

			// AJAX code to submit form.
			$.ajax({
				type: "POST",
				url: "process/process_login.php",
				data: $('.validate-form').serialize(),
				cache: false,
				success: function(html) {
					if(html === "Success"){
						window.location.href = "index.php";
					}else{
						alert(html);
					}
				},
				error: function (xhr, text, error) {              // If 40x or 50x; errors
				  alert('Error: ' + error);
			   }
			});
			check = false;
		}
		

        return check;
    });


    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
        });
    });

    function validate (input) {
        if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
                return false;
            }
        }
        else {
            if($(input).val().trim() == ''){
                return false;
            }
        }
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
    }
    
    

})(jQuery);