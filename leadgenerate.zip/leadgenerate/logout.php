<?php
	
	session_start();
	
	//session destroy
	
	session_destroy();
	
	header("location: index.php");	
	
?>